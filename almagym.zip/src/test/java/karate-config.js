function fn() {

    var config = {
        baseUrl : 'http://localhost:8080'
    };

    return config;
}